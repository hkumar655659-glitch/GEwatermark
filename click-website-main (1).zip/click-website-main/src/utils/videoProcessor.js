/**
 * Video Processor Engine
 * Reverse-engineered from: https://geminiwatermarkremove.net/gemini-omni-video-watermark-remover
 * 
 * Performs client-side, high-performance MP4 video processing:
 * 1. Demuxes H.264 stream using MP4Box.js.
 * 2. Decodes video frames using browser WebCodecs VideoDecoder.
 * 3. Scans bottom-right offsets for watermark alignment using Pearson correlation.
 * 4. Applies subtractive AI formula to restore underlying pixel data.
 * 5. Re-encodes frames using H.264 VideoEncoder.
 * 6. Muxes audio track verbatim alongside cleaned video frames using mp4-muxer.
 */

import ImageProcessor from "./imageProcessor";

const SUPPORTED_RESOLUTIONS = new Set(["1280x720", "720x1280", "1920x1080", "1080x1920"]);
const CANDIDATE_OFFSETS = [144, 120, 128, 72];
const DEPENDENCIES = ["/vendor/mp4box.all.min.js", "/vendor/mp4-muxer.min.js"];

let dependencyPromise = null;
let cachedAlphaMaps = {};

function clamp(val, min, max) {
  return Math.min(Math.max(val, min), max);
}

function getContext2D(canvas) {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) {
    throw new Error("Canvas processing is unavailable in this browser.");
  }
  return ctx;
}

/**
 * Dynamically loads MP4Box and MP4Muxer scripts if not already present.
 */
async function loadDependencies() {
  if (!dependencyPromise) {
    dependencyPromise = DEPENDENCIES.reduce((promise, src) => {
      return promise.then(() => new Promise((resolve, reject) => {
        let script = document.querySelector(`script[src="${src}"]`);
        if (script?.dataset.loaded === "true") {
          return resolve();
        }
        const s = script || document.createElement("script");
        s.src = src;
        s.async = false;
        s.onload = () => {
          s.dataset.loaded = "true";
          resolve();
        };
        s.onerror = () => reject(new Error(`Could not load ${src}.`));
        if (!script) {
          document.head.appendChild(s);
        }
      }));
    }, Promise.resolve());
  }
  await dependencyPromise;
  if (!window.MP4Box || !window.Mp4Muxer) {
    throw new Error("The MP4 processing libraries did not initialize.");
  }
}

/**
 * Loads the watermark alpha map image and processes its luminance values.
 */
async function loadAlphaMap(targetSize = 48) {
  return ImageProcessor.loadAlphaMap(targetSize);
}

/**
 * Computes Pearson correlation score of candidate watermark against current frame background.
 */
function scoreCandidate(frameData, candidate) {
  const map = candidate.alphaMap;
  let sumX = 0, sumXX = 0, sumY = 0, sumYY = 0, sumXY = 0, count = 0;

  for (let row = 0; row < map.height; row++) {
    for (let col = 0; col < map.width; col++) {
      const alphaVal = map.values[row * map.width + col];
      if (alphaVal <= 0.08) continue;

      const pxIdx = ((candidate.y + row) * frameData.width + candidate.x + col) * 4;
      const grayVal = (frameData.data[pxIdx] + frameData.data[pxIdx + 1] + frameData.data[pxIdx + 2]) / 765;

      sumX += grayVal;
      sumXX += grayVal * grayVal;
      sumY += alphaVal;
      sumYY += alphaVal * alphaVal;
      sumXY += grayVal * alphaVal;
      count++;
    }
  }

  if (count === 0) return -Infinity;
  const meanX = sumX / count;
  const meanY = sumY / count;
  const denom = Math.sqrt((sumXX - count * meanX * meanX) * (sumYY - count * meanY * meanY));

  return denom <= 0 ? -Infinity : (sumXY - count * meanX * meanY) / denom;
}

/**
 * Subtracts the watermark logo from selected image data region.
 */
function subtractWatermark(frameData, winningCandidate, settings) {
  const map = winningCandidate.alphaMap;
  const data = frameData.data; // Modify in-place to avoid high GC churn
  const opacity = settings?.opacity ?? 0.62;
  const brightness = settings?.brightness ?? 250;

  for (let row = 0; row < map.height; row++) {
    for (let col = 0; col < map.width; col++) {
      const alphaVal = Math.min(opacity * map.values[row * map.width + col], 0.88);
      if (alphaVal < 0.002) continue;

      const pxIdx = ((winningCandidate.y + row) * frameData.width + winningCandidate.x + col) * 4;
      const s = 1 - alphaVal;

      for (let c = 0; c < 3; c++) {
        data[pxIdx + c] = Math.round(clamp((frameData.data[pxIdx + c] - brightness * alphaVal) / s, 0, 255));
      }
    }
  }

  return frameData;
}

/**
 * Computes frame variance in candidate region to ensure we only align on high-contrast frames.
 */
function getFrameVariance(frameData, candidate) {
  const map = candidate.alphaMap;
  let sumX = 0, sumXX = 0, count = 0;

  for (let row = 0; row < map.height; row++) {
    for (let col = 0; col < map.width; col++) {
      const alphaVal = map.values[row * map.width + col];
      if (alphaVal <= 0.08) continue;

      const pxIdx = ((candidate.y + row) * frameData.width + candidate.x + col) * 4;
      const grayVal = (frameData.data[pxIdx] + frameData.data[pxIdx + 1] + frameData.data[pxIdx + 2]) / 765;

      sumX += grayVal;
      sumXX += grayVal * grayVal;
      count++;
    }
  }

  if (count === 0) return 0;
  const meanX = sumX / count;
  return sumXX / count - meanX * meanX;
}

/**
 * Parses track description header to extract SPS/PPS config bytes.
 */
function getTrackDescription(mp4boxFile, track) {
  const trackEntry = mp4boxFile.getTrackById(track.id);
  const entries = trackEntry?.mdia?.minf?.stbl?.stsd?.entries || [];
  for (const entry of entries) {
    const box = entry.avcC || entry.hvcC || entry.vpcC || entry.av1C;
    if (!box) continue;
    const DataStreamClass = window.DataStream || window.MP4Box?.DataStream;
    if (!DataStreamClass) break;
    const stream = new DataStreamClass(undefined, 0, DataStreamClass.BIG_ENDIAN);
    box.write(stream);
    return new Uint8Array(stream.buffer, 8); // Skip 8-byte box header
  }
  return null;
}

export async function processVideo(arrayBuffer, settingsOrOnProgress, onProgressCallback) {
  let settings = {};
  let onProgress = onProgressCallback;

  if (typeof settingsOrOnProgress === "function") {
    onProgress = settingsOrOnProgress;
    settings = {};
  } else {
    settings = settingsOrOnProgress || {};
  }
  if (typeof VideoDecoder === "undefined" || typeof VideoEncoder === "undefined") {
    throw new Error("This browser does not support WebCodecs video processing. Use a recent version of Chrome, Edge, or Opera.");
  }

  // 1. Ensure mp4box.js and mp4-muxer.js are loaded
  await loadDependencies();

  onProgress({ stage: "demux", ratio: 0 });

  // 2. Demux using MP4Box
  const { videoTrack, audioTrack, videoSamples, audioSamples, videoDescription } = await new Promise((resolve, reject) => {
    const file = window.MP4Box.createFile();
    let vTrack = null;
    let aTrack = null;
    const vSamples = [];
    const aSamples = [];

    file.onError = (err) => reject(new Error(`MP4 demux failed: ${String(err)}`));

    file.onReady = (info) => {
      vTrack = info.videoTracks?.[0];
      aTrack = info.audioTracks?.[0];

      if (!vTrack) {
        return reject(new Error("No video track found in this MP4."));
      }

      file.setExtractionOptions(vTrack.id, "video", { nbSamples: 1000000 });
      if (aTrack) {
        file.setExtractionOptions(aTrack.id, "audio", { nbSamples: 1000000 });
      }
      file.start();
    };

    file.onSamples = (id, ref, samples) => {
      const targetList = (id === vTrack.id) ? vSamples : aSamples;
      for (const sample of samples) {
        targetList.push({ ...sample, data: sample.data.slice(0) });
      }
    };

    // Feed buffer
    const buf = arrayBuffer.slice(0);
    buf.fileStart = 0;
    file.appendBuffer(buf);
    file.flush();

    if (vTrack) {
      resolve({
        videoTrack: vTrack,
        audioTrack: aTrack,
        videoSamples: vSamples,
        audioSamples: aSamples,
        videoDescription: getTrackDescription(file, vTrack)
      });
    } else {
      reject(new Error("No video track found in this MP4."));
    }
  });

  onProgress({ stage: "demux", ratio: 1 });

  const width = videoTrack.video.width;
  const height = videoTrack.video.height;
  const totalSamples = videoSamples.length || 1;
  const timescale = videoSamples[0]?.timescale ?? videoTrack.timescale ?? 30000;
  const sampleDuration = videoSamples.reduce((sum, s) => sum + s.duration, 0) / totalSamples || timescale / 30;
  const fps = Math.max(1, Math.round(timescale / sampleDuration));

  // Calculate dynamic scale and watermark size relative to baseline (720p)
  const baselineWidth = (width >= height) ? 1280 : 720;
  const scale = Number((width / baselineWidth).toFixed(2));
  const sizeAdjustment = settings?.sizeAdjustment ?? 0;
  const targetWatermarkSize = Math.max(16, Math.round(48 * scale) + sizeAdjustment);

  // Load watermark alpha map
  const alphaMap = await loadAlphaMap(targetWatermarkSize);

  // Set up candidate positions at bottom-right based on candidate offsets scaled dynamically
  const candidates = CANDIDATE_OFFSETS.map(offset => {
    const scaledOffset = Math.round(offset * scale);
    return {
      x: clamp(width - scaledOffset, 0, width - alphaMap.width),
      y: clamp(height - scaledOffset, 0, height - alphaMap.height),
      alphaMap,
      score: 0,
      baseStrength: 1
    };
  });

  // Number of frames to evaluate correlation score
  const scoreFramesCount = Math.min(5, totalSamples);
  let bestCandidate = null;

  // 3. Initialize MP4 Muxer
  const muxer = new window.Mp4Muxer.Muxer({
    target: new window.Mp4Muxer.ArrayBufferTarget(),
    fastStart: "in-memory",
    firstTimestampBehavior: "offset",
    video: {
      codec: "avc",
      width,
      height
    },
    audio: audioTrack ? {
      codec: "aac",
      sampleRate: audioTrack.audio.sample_rate,
      numberOfChannels: audioTrack.audio.channel_count
    } : undefined
  });

  // Calculate appropriate bitrate
  const bitrate = Math.max(2000000, Math.min(20000000, Math.round(width * height * fps * 0.12)));

  // 4. Initialize VideoEncoder
  let encoderError = null;
  const encoder = new VideoEncoder({
    output: (chunk, metadata) => {
      muxer.addVideoChunk(chunk, metadata);
    },
    error: (err) => {
      encoderError = err;
    }
  });

  let encoderConfig = {
    codec: "avc1.640028", // High Profile
    width,
    height,
    bitrate,
    framerate: fps,
    avc: { format: "avc" }
  };

  let isConfigSupported = await VideoEncoder.isConfigSupported(encoderConfig);
  if (!isConfigSupported.supported) {
    encoderConfig = { ...encoderConfig, codec: "avc1.42001f" }; // Baseline Profile fallback
    isConfigSupported = await VideoEncoder.isConfigSupported(encoderConfig);
    if (!isConfigSupported.supported) {
      throw new Error("This browser does not support standard H.264 MP4 video encoding.");
    }
  }
  encoder.configure(encoderConfig);

  const tempCanvas = document.createElement("canvas");
  tempCanvas.width = width;
  tempCanvas.height = height;
  const tempCtx = getContext2D(tempCanvas);

  let framesDecodedCount = 0;
  let framesProcessedCount = 0;
  let processingError = null;
  const frameQueue = [];

  // Processes a decoded frame and applies subtractive reconstruction
  const processFrame = (frameItem) => {
    const cleanedData = subtractWatermark(frameItem.imageData, bestCandidate || candidates[0], settings);
    const frameOptions = {
      format: "RGBA",
      codedWidth: width,
      codedHeight: height,
      timestamp: frameItem.timestamp
    };
    if (frameItem.duration != null) {
      frameOptions.duration = frameItem.duration;
    }

    const processedFrame = new VideoFrame(cleanedData.data.buffer, frameOptions);
    const keyFrameInterval = Math.max(1, 2 * fps);
    const isKeyFrame = (framesProcessedCount % keyFrameInterval === 0);

    encoder.encode(processedFrame, { keyFrame: isKeyFrame });
    processedFrame.close();

    framesProcessedCount++;
    onProgress({ stage: "process", ratio: framesProcessedCount / totalSamples });
  };

  // 5. Initialize VideoDecoder
  const decoder = new VideoDecoder({
    output: async (frame) => {
      try {
        const timestamp = frame.timestamp;
        const duration = frame.duration;

        // Render to canvas to capture pixels
        tempCtx.drawImage(frame, 0, 0, width, height);
        frame.close();

        const imgData = tempCtx.getImageData(0, 0, width, height);
        const frameItem = { imageData: imgData, timestamp, duration };

        if (!bestCandidate) {
          const variance = getFrameVariance(imgData, candidates[0]);
          const isUsableFrame = variance > 0.002 || framesDecodedCount > 30;

          if (isUsableFrame) {
            // Coarse search bounds in the bottom-right quadrant
            const searchW = Math.min(width, Math.round(240 * scale));
            const searchH = Math.min(height, Math.round(240 * scale));
            const startX = width - searchW;
            const startY = height - searchH;
            const endX = width - alphaMap.width;
            const endY = height - alphaMap.height;

            let coarseBestX = startX;
            let coarseBestY = startY;
            let coarseBestScore = -Infinity;
            const coarseStep = 3;

            // 1. Coarse scan to locate the rough neighborhood using default size
            for (let yPos = startY; yPos <= endY; yPos += coarseStep) {
              for (let xPos = startX; xPos <= endX; xPos += coarseStep) {
                const score = scoreCandidate(imgData, { x: xPos, y: yPos, alphaMap });
                if (score > coarseBestScore) {
                  coarseBestScore = score;
                  coarseBestX = xPos;
                  coarseBestY = yPos;
                }
              }
            }

            // 2. Evaluate multiple watermark sizes around this rough location to find best fit
            const baselineSizes = [36, 48, 96];
            const candidateSizes = [];

            for (const base of baselineSizes) {
              const centerSize = Math.round(base * scale);
              for (let offset = -4; offset <= 4; offset += 2) {
                const sz = centerSize + offset;
                if (sz >= 16 && !candidateSizes.includes(sz)) {
                  candidateSizes.push(sz);
                }
              }
            }

            let absoluteBestCandidate = null;
            let absoluteBestScore = -Infinity;

            for (const size of candidateSizes) {
              const sizeMap = await loadAlphaMap(size);
              
              // Run fine scan for this size in a +/- 6 window around coarse peak
              const fineRange = 6;
              let sizeBestX = coarseBestX;
              let sizeBestY = coarseBestY;
              let sizeBestScore = -Infinity;

              for (let dy = -fineRange; dy <= fineRange; dy++) {
                for (let dx = -fineRange; dx <= fineRange; dx++) {
                  const candX = clamp(coarseBestX + dx, startX, width - sizeMap.width);
                  const candY = clamp(coarseBestY + dy, startY, height - sizeMap.height);
                  const score = scoreCandidate(imgData, { x: candX, y: candY, alphaMap: sizeMap });
                  if (score > sizeBestScore) {
                    sizeBestScore = score;
                    sizeBestX = candX;
                    sizeBestY = candY;
                  }
                }
              }

              if (sizeBestScore > absoluteBestScore) {
                absoluteBestScore = sizeBestScore;
                absoluteBestCandidate = {
                  x: sizeBestX,
                  y: sizeBestY,
                  alphaMap: sizeMap,
                  score: sizeBestScore
                };
              }
            }

            bestCandidate = absoluteBestCandidate || {
              x: coarseBestX,
              y: coarseBestY,
              alphaMap,
              score: coarseBestScore
            };

            console.log(`[GWMR] Watermark Auto-Detected: size=${bestCandidate.alphaMap.width}px, x=${bestCandidate.x}, y=${bestCandidate.y} (offset right=${width - bestCandidate.x}, bottom=${height - bestCandidate.y}) with correlation score=${bestCandidate.score.toFixed(4)}`);

            // Process queued frames
            frameQueue.push(frameItem);
            for (const item of frameQueue) {
              processFrame(item);
            }
            frameQueue.length = 0;
          } else {
            frameQueue.push(frameItem);
            framesDecodedCount++;
          }
        } else {
          processFrame(frameItem);
        }
      } catch (err) {
        processingError = err;
      }
    },
    error: (err) => {
      processingError = err;
    }
  });

  decoder.configure({
    codec: videoTrack.codec,
    codedWidth: width,
    codedHeight: height,
    description: videoDescription || undefined
  });

  // Feed all samples into the decoder
  for (let i = 0; i < videoSamples.length; i++) {
    if (processingError) throw processingError;
    const sample = videoSamples[i];
    decoder.decode(new EncodedVideoChunk({
      type: sample.is_sync ? "key" : "delta",
      timestamp: (1000000 * sample.cts) / sample.timescale,
      duration: (1000000 * sample.duration) / sample.timescale,
      data: sample.data
    }));

    // Yield execution to UI thread to prevent browser lockup
    if (i % 24 === 0) {
      await new Promise(r => window.setTimeout(r, 0));
    }
  }

  await decoder.flush();
  await encoder.flush();

  if (processingError) throw processingError;
  if (encoderError) throw encoderError;

  decoder.close();
  encoder.close();

  // 6. Mux Audio verbatim if it exists
  if (audioTrack && audioSamples.length > 0) {
    try {
      const audioTimescale = audioTrack.audio.sample_rate;
      const audioChannels = audioTrack.audio.channel_count;

      // Compute descriptive metadata config bytes for AAC AudioDecoder
      let frequencyIdx = [
        96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350
      ].indexOf(audioTimescale);
      if (frequencyIdx < 0) frequencyIdx = 4; // Default to 44100

      const description = new Uint8Array([
        16 | (frequencyIdx >> 1),
        ((frequencyIdx & 1) << 7) | (audioChannels << 3)
      ]);

      const audioConfig = {
        decoderConfig: {
          codec: "mp4a.40.2", // AAC-LC
          sampleRate: audioTimescale,
          numberOfChannels: audioChannels,
          description
        }
      };

      for (const sample of audioSamples) {
        muxer.addAudioChunk(new EncodedAudioChunk({
          type: "key",
          timestamp: (1000000 * sample.cts) / sample.timescale,
          duration: (1000000 * sample.duration) / sample.timescale,
          data: sample.data
        }), audioConfig);
      }
    } catch (err) {
      console.warn("Audio copy failed; exporting video-only MP4.", err);
    }
  }

  onProgress({ stage: "mux", ratio: 0.95 });
  muxer.finalize();
  onProgress({ stage: "done", ratio: 1.0 });

  return new Blob([muxer.target.buffer], { type: "video/mp4" });
}

export function getCleanedFilename(filename) {
  return `${filename.replace(/\.[^.]+$/, "") || "gemini-video"}-cleaned.mp4`;
}

export function downloadFile(url, filename) {
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
}
