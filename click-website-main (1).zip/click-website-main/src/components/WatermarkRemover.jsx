import { useState, useRef, useEffect } from "react";
import { processVideo, getCleanedFilename, downloadFile } from "../utils/videoProcessor";
import ImageProcessor from "../utils/imageProcessor";

export default function WatermarkRemover() {
  const [workspaceMode, setWorkspaceMode] = useState("video"); // "video" or "image"

  // Video states
  const [queue, setQueue] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Image states
  const [imageQueue, setImageQueue] = useState([]);
  const [selectedImageId, setSelectedImageId] = useState(null);
  const [isImageProcessing, setIsImageProcessing] = useState(false);
  const [imageSettings, setImageSettings] = useState({
    method: "subtraction", // "subtraction", "blur", "solid", "clone"
    radius: 8,
    solidColor: "",
    cloneOffset: { x: -80, y: 0 },
    feather: 10
  });

  const [videoSettings, setVideoSettings] = useState({
    opacity: 0.62,
    brightness: 250,
    sizeAdjustment: 0,
  });

  const [lightboxUrl, setLightboxUrl] = useState(null);
  const [lightboxTitle, setLightboxTitle] = useState("");

  // Comparison slider & HUD states
  const [imageViewMode, setImageViewMode] = useState("side-by-side"); // "side-by-side" or "split-slider"
  const [imageSliderPos, setImageSliderPos] = useState(50);
  const [isDraggingSlider, setIsDraggingSlider] = useState(false);
  const sliderRef = useRef(null);

  useEffect(() => {
    if (!isDraggingSlider) return;

    const handlePointerMoveGlobal = (e) => {
      if (!sliderRef.current) return;
      const rect = sliderRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
      setImageSliderPos(percentage);
    };

    const handlePointerUpGlobal = () => {
      setIsDraggingSlider(false);
    };

    window.addEventListener("pointermove", handlePointerMoveGlobal);
    window.addEventListener("pointerup", handlePointerUpGlobal);

    return () => {
      window.removeEventListener("pointermove", handlePointerMoveGlobal);
      window.removeEventListener("pointerup", handlePointerUpGlobal);
    };
  }, [isDraggingSlider]);

  const fileInputRef = useRef(null);
  const imageFileInputRef = useRef(null);
  const activeUrls = useRef(new Set());

  const handleSettingChange = (key, value) => {
    setImageSettings((prev) => ({
      ...prev,
      [key]: value
    }));
  };

  const handleCloneOffsetChange = (key, value) => {
    setImageSettings((prev) => ({
      ...prev,
      cloneOffset: {
        ...prev.cloneOffset,
        [key]: parseInt(value)
      }
    }));
  };

  const handleVideoSettingChange = (key, value) => {
    setVideoSettings((prev) => ({
      ...prev,
      [key]: value
    }));
  };

  // Revoke all created URLs on unmount and handle Escape key for lightbox
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape") {
        setLightboxUrl(null);
      }
    };
    window.addEventListener("keydown", handleKeyDown);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      activeUrls.current.forEach((url) => URL.revokeObjectURL(url));
      activeUrls.current.clear();
    };
  }, []);

  const trackUrl = (url) => {
    activeUrls.current.add(url);
    return url;
  };

  const revokeUrl = (url) => {
    if (url) {
      URL.revokeObjectURL(url);
      activeUrls.current.delete(url);
    }
  };

  const [overallError, setOverallError] = useState(null);

  // Active items
  const activeItem = queue.find((item) => item.id === selectedId) || queue[0] || null;
  const activeImageItem = imageQueue.find((item) => item.id === selectedImageId) || imageQueue[0] || null;

  const handleChooseVideoClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleChooseImageClick = () => {
    if (imageFileInputRef.current) {
      imageFileInputRef.current.click();
    }
  };

  // Video Handlers
  const handleFileChange = async (e) => {
    const files = Array.from(e.target.files || []).filter((f) =>
      f.type.startsWith("video/")
    );
    if (files.length === 0) {
      setOverallError("Please select valid MP4 video files.");
      return;
    }

    setOverallError(null);
    const newItems = [];

    for (const file of files) {
      const sourceUrl = trackUrl(URL.createObjectURL(file));
      const id = crypto.randomUUID();

      // Read video dimensions
      try {
        const dimensions = await new Promise((resolve, reject) => {
          const video = document.createElement("video");
          video.preload = "metadata";
          video.src = sourceUrl;
          video.onloadedmetadata = () => {
            resolve(`${video.videoWidth}x${video.videoHeight}`);
          };
          video.onerror = () => {
            reject(new Error("Could not read video dimensions."));
          };
        });

        const isSupported = dimensions === "1280x720" || dimensions === "720x1280" || dimensions === "1920x1080" || dimensions === "1080x1920";

        newItems.push({
          id,
          file,
          name: file.name,
          size: file.size,
          dimensions,
          sourceUrl,
          outputUrl: null,
          progress: 0,
          status: isSupported ? "ready" : "error",
          error: isSupported
            ? null
            : `Unsupported dimensions: ${dimensions.replace(
              "x",
              " x "
            )}. Use exact 1280 x 720, 720 x 1280, 1920 x 1080, or 1080 x 1920. (Why? Our client-side AI subtraction logic uses a pre-calibrated watermark mask scaled dynamically to prevent alignment artifacts.)`,
        });
      } catch (err) {
        newItems.push({
          id,
          file,
          name: file.name,
          size: file.size,
          dimensions: "unknown",
          sourceUrl,
          outputUrl: null,
          progress: 0,
          status: "error",
          error: "Failed to read video metadata.",
        });
      }
    }

    if (newItems.length > 0) {
      setQueue((prev) => {
        const nextQueue = [...prev, ...newItems];
        if (!selectedId) {
          setSelectedId(newItems[0].id);
        }
        return nextQueue;
      });
    }

    if (e.target) {
      e.target.value = "";
    }
  };

  const handleRemoveVideo = (id, e) => {
    if (e) e.stopPropagation();

    setQueue((prev) => {
      const target = prev.find((item) => item.id === id);
      if (target) {
        revokeUrl(target.sourceUrl);
        revokeUrl(target.outputUrl);
      }
      const nextQueue = prev.filter((item) => item.id !== id);

      if (selectedId === id) {
        setSelectedId(nextQueue[0]?.id || null);
      }
      return nextQueue;
    });
  };

  const updateItem = (id, updates) => {
    setQueue((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updates } : item))
    );
  };

  const cleanVideoItem = async (item) => {
    if (!item || item.status === "error") return;

    if (item.outputUrl) {
      revokeUrl(item.outputUrl);
      updateItem(item.id, { outputUrl: null });
    }

    updateItem(item.id, {
      status: "processing",
      progress: 0,
      error: null,
    });

    try {
      const arrayBuffer = await item.file.arrayBuffer();
      const cleanedBlob = await processVideo(arrayBuffer, videoSettings, ({ stage, ratio }) => {
        let pct = 0;
        if (stage === "demux") {
          pct = Math.round(ratio * 8);
        } else if (stage === "process") {
          pct = Math.round(8 + ratio * 88);
        } else if (stage === "mux") {
          pct = 97;
        } else if (stage === "done") {
          pct = 100;
        }
        updateItem(item.id, { progress: pct });
      });

      const outputUrl = trackUrl(URL.createObjectURL(cleanedBlob));
      updateItem(item.id, {
        outputUrl,
        status: "done",
        progress: 100,
      });
      return outputUrl;
    } catch (err) {
      console.error(err);
      const msg = err instanceof Error ? err.message : "Video cleaning failed.";
      updateItem(item.id, {
        status: "error",
        error: msg,
      });
      throw err;
    }
  };

  const handleCleanVideo = async () => {
    if (!activeItem || activeItem.status === "error" || isProcessing) return;

    setIsProcessing(true);
    setOverallError(null);

    try {
      await cleanVideoItem(activeItem);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Video cleaning failed.";
      setOverallError(msg);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCleanAllVideos = async () => {
    const processableItems = queue.filter(
      (item) => item.status === "ready" || item.status === "done" || item.status === "error"
    );
    if (processableItems.length === 0 || isProcessing) return;

    setIsProcessing(true);
    setOverallError(null);

    const concurrencyLimit = 2;
    const itemsCopy = [...processableItems];
    const pool = [];

    const worker = async () => {
      while (itemsCopy.length > 0) {
        const item = itemsCopy.shift();
        if (!item) continue;
        try {
          await cleanVideoItem(item);
        } catch (err) {
          console.error(`Error processing bulk item: ${item.name}`, err);
        }
      }
    };

    // Spawn concurrent workers
    const spawnCount = Math.min(concurrencyLimit, processableItems.length);
    for (let i = 0; i < spawnCount; i++) {
      pool.push(worker());
    }

    try {
      await Promise.all(pool);
    } catch (err) {
      console.error("Error running parallel processing", err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownloadAllVideos = () => {
    const cleanedItems = queue.filter((item) => item.outputUrl);
    cleanedItems.forEach((item, index) => {
      setTimeout(() => {
        downloadFile(item.outputUrl, getCleanedFilename(item.name));
      }, index * 400);
    });
  };


  const handleClearQueue = () => {
    queue.forEach((item) => {
      revokeUrl(item.sourceUrl);
      revokeUrl(item.outputUrl);
    });
    setQueue([]);
    setSelectedId(null);
    setOverallError(null);
  };

  const handleDownload = () => {
    if (activeItem && activeItem.outputUrl) {
      downloadFile(activeItem.outputUrl, getCleanedFilename(activeItem.name));
    }
  };

  // Image Handlers
  const handleImageFileChange = async (e) => {
    const files = Array.from(e.target.files || []).filter((f) =>
      f.type.startsWith("image/")
    );
    if (files.length === 0) {
      setOverallError("Please select valid image files.");
      return;
    }

    setOverallError(null);
    const newItems = [];

    for (const file of files) {
      const sourceUrl = trackUrl(URL.createObjectURL(file));
      const id = crypto.randomUUID();

      try {
        const dimensionsData = await new Promise((resolve, reject) => {
          const img = new Image();
          img.onload = () => resolve({ width: img.width, height: img.height });
          img.onerror = () => reject(new Error("Failed to read image dimensions."));
          img.src = sourceUrl;
        });

        const dimensions = `${dimensionsData.width}x${dimensionsData.height}`;
        const baselineWidth = (dimensionsData.width >= dimensionsData.height) ? 1280 : 720;
        const scale = Number((dimensionsData.width / baselineWidth).toFixed(2));
        const targetWatermarkSize = Math.max(16, Math.round(48 * scale));

        newItems.push({
          id,
          file,
          name: file.name,
          size: file.size,
          dimensions,
          width: dimensionsData.width,
          height: dimensionsData.height,
          scale,
          targetWatermarkSize,
          sourceUrl,
          outputUrl: null,
          status: "ready",
          error: null,
        });
      } catch (err) {
        newItems.push({
          id,
          file,
          name: file.name,
          size: file.size,
          dimensions: "unknown",
          sourceUrl,
          outputUrl: null,
          status: "error",
          error: "Failed to read image metadata.",
        });
      }
    }

    if (newItems.length > 0) {
      setImageQueue((prev) => {
        const nextQueue = [...prev, ...newItems];
        if (!selectedImageId) {
          setSelectedImageId(newItems[0].id);
        }
        return nextQueue;
      });
    }

    if (e.target) {
      e.target.value = "";
    }
  };

  const handleRemoveImage = (id, e) => {
    if (e) e.stopPropagation();

    setImageQueue((prev) => {
      const target = prev.find((item) => item.id === id);
      if (target) {
        revokeUrl(target.sourceUrl);
        revokeUrl(target.outputUrl);
      }
      const nextQueue = prev.filter((item) => item.id !== id);

      if (selectedImageId === id) {
        setSelectedImageId(nextQueue[0]?.id || null);
      }
      return nextQueue;
    });
  };

  const updateImageItem = (id, updates) => {
    setImageQueue((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updates } : item))
    );
  };

  const handleCleanImage = async () => {
    if (!activeImageItem || activeImageItem.status === "error" || isImageProcessing) return;

    setIsImageProcessing(true);
    setOverallError(null);

    if (activeImageItem.outputUrl) {
      revokeUrl(activeImageItem.outputUrl);
      updateImageItem(activeImageItem.id, { outputUrl: null });
    }

    updateImageItem(activeImageItem.id, {
      status: "processing",
      progress: 20,
      error: null
    });

    try {
      const img = new Image();
      img.src = activeImageItem.sourceUrl;
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = () => reject(new Error("Failed to load image source."));
      });

      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0);

      updateImageItem(activeImageItem.id, { progress: 50 });

      // Retrieve dynamic scale and target watermark size calculated on upload
      const scale = activeImageItem.scale || 1.0;
      const targetWatermarkSize = activeImageItem.targetWatermarkSize || 48;

      // Scale the search area width & height accordingly (search bottom-right quadrant)
      const w = Math.min(canvas.width, Math.round(200 * scale));
      const h = Math.min(canvas.height, Math.round(200 * scale));
      const x = Math.max(0, canvas.width - w);
      const y = Math.max(0, canvas.height - h);

      // Load scaled alpha map dynamically
      const alphaMap = await ImageProcessor.loadAlphaMap(targetWatermarkSize);
      
      // Locate the watermark exact position inside search bounds asynchronously via Web Worker
      const pos = await ImageProcessor.findBestWatermarkPositionAsync(ctx, x, y, w, h, alphaMap);

      if (imageSettings.method === "subtraction") {
        ImageProcessor.subtractWatermark(ctx, { x: pos.x, y: pos.y, alphaMap });
      } else {
        // For local operations (blur, solid, clone), apply on the localized bounding box with padding
        const pad = Math.round(4 * scale);
        const bx = Math.max(0, pos.x - pad);
        const by = Math.max(0, pos.y - pad);
        const bw = Math.min(canvas.width - bx, targetWatermarkSize + 2 * pad);
        const bh = Math.min(canvas.height - by, targetWatermarkSize + 2 * pad);

        if (imageSettings.method === "blur") {
          ImageProcessor.applyBlur(ctx, bx, by, bw, bh, imageSettings.radius);
        } else if (imageSettings.method === "solid") {
          const autoColor = ImageProcessor.detectBorderColor(ctx, bx, by, bw, bh);
          const fillColor = imageSettings.solidColor || autoColor;
          ImageProcessor.applySolidFill(ctx, bx, by, bw, bh, fillColor, imageSettings.feather);
        } else if (imageSettings.method === "clone") {
          // Scale offset values to align with high resolution pixel counts
          const realOffsetX = Math.round(imageSettings.cloneOffset.x * scale);
          const realOffsetY = Math.round(imageSettings.cloneOffset.y * scale);
          ImageProcessor.applyClonePatch(
            ctx, bx, by, bw, bh,
            realOffsetX,
            realOffsetY,
            imageSettings.feather
          );
        }
      }

      updateImageItem(activeImageItem.id, { progress: 85 });

      const cleanedBlob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
      const outputUrl = trackUrl(URL.createObjectURL(cleanedBlob));

      updateImageItem(activeImageItem.id, {
        outputUrl,
        status: "done",
        progress: 100,
        detectedPos: pos
      });

      // Auto-open lightbox on completion
      setLightboxUrl(outputUrl);
      setLightboxTitle("Cleaned Output Preview");
    } catch (err) {
      console.error(err);
      const msg = err instanceof Error ? err.message : "Image cleaning failed.";
      updateImageItem(activeImageItem.id, {
        status: "error",
        error: msg
      });
      setOverallError(msg);
    } finally {
      setIsImageProcessing(false);
    }
  };

  const handleClearImageQueue = () => {
    imageQueue.forEach((item) => {
      revokeUrl(item.sourceUrl);
      revokeUrl(item.outputUrl);
    });
    setImageQueue([]);
    setSelectedImageId(null);
    setOverallError(null);
  };

  const handleDownloadImage = () => {
    if (activeImageItem && activeImageItem.outputUrl) {
      const cleanName = `${activeImageItem.name.replace(/\.[^.]+$/, "") || "cleaned"}-cleaned.png`;
      downloadFile(activeImageItem.outputUrl, cleanName);
    }
  };

  const isPortrait = activeItem?.dimensions === "720x1280";
  const hasOutput = !!activeItem?.outputUrl;
  const isReady = activeItem && activeItem.status !== "error";

  const isImageReady = activeImageItem && activeImageItem.status !== "error";
  const hasImageOutput = !!activeImageItem?.outputUrl;

  const viewerClassName = hasOutput && isPortrait
    ? "grid gap-4 md:grid-cols-2"
    : "grid gap-4";

  return (
    <div className="lovable-theme shadow-sm transition-all duration-200 overflow-hidden p-0">
      {/* Header bar */}
      <div className="border-b border-border bg-muted/40 p-5 sm:p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary/70">
                <rect width="18" height="18" x="3" y="3" rx="2" />
                <path d="M7 3v18" />
                <path d="M3 7.5h4" />
                <path d="M3 12h18" />
                <path d="M3 16.5h4" />
                <path d="M17 3v18" />
                <path d="M17 7.5h4" />
                <path d="M17 16.5h4" />
              </svg>
              Gemini Omni Media Studio | GWMR Net
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              Local client-side watermark removal for videos and images.
            </p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border bg-muted/20">
        <button
          onClick={() => {
            setWorkspaceMode("video");
            setOverallError(null);
          }}
          className={`flex-1 py-3 text-center text-xs font-bold uppercase tracking-wider transition-colors border-b-2 cursor-pointer ${
            workspaceMode === "video"
              ? "border-primary text-foreground bg-card/5"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          Video Cleaner
        </button>
        <button
          onClick={() => {
            setWorkspaceMode("image");
            setOverallError(null);
          }}
          className={`flex-1 py-3 text-center text-xs font-bold uppercase tracking-wider transition-colors border-b-2 cursor-pointer ${
            workspaceMode === "image"
              ? "border-primary text-foreground bg-card/5"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          Image Cleaner
        </button>
      </div>

      {/* Main body split in visual canvas & sidebar controls */}
      <div className="grid gap-0 lg:grid-cols-[minmax(0,1fr)_300px]">
        {/* Left Side: Visual Canvas Display */}
        <div className="min-w-0 lovable-video-workspace p-3 sm:p-5 border-r border-border">
          {/* Video mode visual workspace */}
          {workspaceMode === "video" && (
            activeItem ? (
              <>
                <div className={viewerClassName}>
                  <div className="min-w-0">
                    <div className="mb-2 text-[10px] font-black uppercase tracking-[0.18em] text-white/65">
                      Original Video
                    </div>
                    <video
                      src={activeItem.sourceUrl}
                      controls={!isProcessing}
                      playsInline
                      className="mx-auto block max-h-[34rem] w-full bg-black object-contain rounded-lg"
                    />
                  </div>

                  {activeItem.outputUrl && (
                    <div className="min-w-0">
                      <div className="mb-2 text-[10px] font-black uppercase tracking-[0.18em] text-emerald-300">
                        Cleaned Output Preview
                      </div>
                      <video
                        src={activeItem.outputUrl}
                        controls
                        playsInline
                        className="mx-auto block max-h-[34rem] w-full bg-black object-contain rounded-lg"
                      />
                    </div>
                  )}
                </div>

                {/* Queue Files List Grid */}
                <div className="mt-10 border border-border bg-card/20 rounded-2xl p-5 sm:p-6 shadow-sm">
                  <div className="flex items-center justify-between border-b border-border/60 pb-4 mb-5">
                    <div>
                      <h3 className="text-sm font-bold text-foreground uppercase tracking-wider">
                        Queue Files Grid ({queue.length})
                      </h3>
                      <p className="text-[11px] text-muted-foreground mt-0.5">
                        Select a card to configure fine-tuning and process
                      </p>
                    </div>
                  </div>

                  <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
                    {queue.map((item, index) => {
                      const sizeMB = (item.size / (1024 * 1024)).toFixed(1);
                      const isActive = item.id === activeItem?.id;
                      
                      // Extract name and extension
                      const nameParts = item.name.split(".");
                      const extension = nameParts.length > 1 ? nameParts.pop() : "";
                      const baseName = nameParts.join(".");

                      return (
                        <div 
                          key={item.id}
                          onClick={() => setSelectedId(item.id)}
                          className={`group relative rounded-xl border transition-all duration-300 cursor-pointer overflow-hidden flex flex-col justify-between bg-[#131316]/90 ${
                            isActive 
                              ? "border-primary bg-primary/[0.03] shadow-[0_0_20px_rgba(59,130,246,0.15)] ring-1 ring-primary/40 scale-[1.02]" 
                              : "border-border/60 hover:border-primary/40 hover:bg-muted/15 hover:shadow-[0_8px_20px_rgba(0,0,0,0.3)] hover:-translate-y-1"
                          }`}
                        >
                          {/* Mini Aspect Video Frame */}
                          <div className="relative aspect-video w-full bg-black overflow-hidden flex items-center justify-center border-b border-border/30">
                            {/* Real video first frame display */}
                            <video
                              src={item.sourceUrl}
                              className="w-full h-full object-cover opacity-60 group-hover:opacity-85 transition-opacity duration-300 pointer-events-none"
                              preload="metadata"
                              muted
                              playsInline
                            />
                            
                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent pointer-events-none" />

                            {/* Resolution Badge - Styled with inline absolute styles for safety */}
                            <span 
                              style={{ position: "absolute", top: "10px", left: "10px" }}
                              className="text-[9px] bg-black/75 text-white/90 font-black px-2 py-0.5 rounded border border-white/10 backdrop-blur-md uppercase tracking-wide"
                            >
                              {item.dimensions || "Video"}
                            </span>
                            
                            {/* Size Badge */}
                            <span 
                              style={{ position: "absolute", bottom: "10px", right: "10px" }}
                              className="text-[9px] bg-black/80 text-white/90 font-black px-2 py-0.5 rounded border border-white/10 backdrop-blur-md"
                            >
                              {sizeMB} MB
                            </span>
                            
                            {/* Selected Indicator */}
                            {isActive && (
                              <span 
                                style={{ position: "absolute", top: "10px", right: "10px" }}
                                className="flex h-5.5 w-5.5 items-center justify-center rounded-full bg-primary text-white shadow-lg border border-primary-foreground/20 animate-scale-up"
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
                                  <polyline points="20 6 9 17 4 12" />
                                </svg>
                              </span>
                            )}
                          </div>

                          {/* Content / Info */}
                          <div className="p-3.5 flex-1 flex flex-col justify-between gap-3 bg-card/20">
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5 min-w-0">
                                <span className="text-[11px] font-bold text-foreground truncate flex-1" title={item.name}>
                                  {index + 1}. {baseName}
                                </span>
                                {extension && (
                                  <span className="text-[8px] bg-white/5 border border-white/10 px-1 py-0.5 rounded uppercase font-black text-muted-foreground shrink-0 leading-none">
                                    {extension}
                                  </span>
                                )}
                              </div>
                            </div>
                            
                            <div className="flex items-center justify-between pt-2.5 border-t border-border/20">
                              <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                                item.status === "done" ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" :
                                item.status === "processing" ? "bg-primary/10 text-primary-foreground border border-primary/20 animate-pulse" :
                                item.status === "error" ? "bg-destructive/10 text-destructive border border-destructive/20" :
                                "bg-muted text-muted-foreground border border-border/40"
                              }`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${
                                  item.status === "done" ? "bg-emerald-400 animate-pulse" :
                                  item.status === "processing" ? "bg-primary" :
                                  item.status === "error" ? "bg-destructive" :
                                  "bg-muted-foreground"
                                }`} />
                                {item.status === "processing" ? `${Math.round(item.progress)}%` : item.status}
                              </span>

                              <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                                {item.outputUrl && (
                                  <button
                                    onClick={() => downloadFile(item.outputUrl, getCleanedFilename(item.name))}
                                    className="lovable-btn-success inline-flex h-7.5 px-3 items-center justify-center rounded-[6px] text-[10px] font-bold shadow-sm transition-all hover:scale-105"
                                  >
                                    Download
                                  </button>
                                )}
                                <button
                                  onClick={(e) => handleRemoveVideo(item.id, e)}
                                  className="inline-flex h-7.5 w-7.5 items-center justify-center rounded-[6px] border border-border text-muted-foreground hover:bg-destructive/10 hover:text-destructive hover:border-destructive/30 transition-colors"
                                  aria-label="Delete video"
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                                    <polyline points="3 6 5 6 21 6" />
                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
                                  </svg>
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </>
            ) : (
              <button
                type="button"
                onClick={handleChooseVideoClick}
                className="flex min-h-80 w-full flex-col items-center justify-center border border-dashed border-primary/20 rounded-lg px-5 text-center transition-all hover:bg-primary/[0.02] hover:border-primary/40 bg-transparent cursor-pointer"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary/50">
                  <path d="M12 3v12" />
                  <path d="m17 8-5-5-5 5" />
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                </svg>
                <span className="mt-4 text-base font-medium text-foreground">Upload a 720p or 1080p video</span>
                <span className="mt-1 text-xs text-muted-foreground">Supports exact 1280x720, 720x1280, 1920x1080, and 1080x1920 resolutions</span>
              </button>
            )
          )}

          {/* Image mode visual workspace */}
          {workspaceMode === "image" && (
            activeImageItem ? (
              <div className="flex flex-col gap-4">
                {/* View Mode Toggle when cleaned output is available */}
                {hasImageOutput && (
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setImageViewMode("side-by-side")}
                      className={`px-3 py-1.5 rounded-[6px] text-[10px] font-bold uppercase tracking-wider transition-colors cursor-pointer border ${
                        imageViewMode === "side-by-side"
                          ? "bg-primary border-primary text-white shadow-sm font-black"
                          : "bg-muted/40 border-border text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      Side by Side
                    </button>
                    <button
                      type="button"
                      onClick={() => setImageViewMode("split-slider")}
                      className={`px-3 py-1.5 rounded-[6px] text-[10px] font-bold uppercase tracking-wider transition-colors cursor-pointer border ${
                        imageViewMode === "split-slider"
                          ? "bg-primary border-primary text-white shadow-sm font-black"
                          : "bg-muted/40 border-border text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      Before / After Slider
                    </button>
                  </div>
                )}

                {imageViewMode === "split-slider" && hasImageOutput ? (
                  <div className="min-w-0">
                    <div className="mb-2 text-[10px] font-black uppercase tracking-[0.18em] text-emerald-300 flex justify-between items-center">
                      <span>Before / After Comparison</span>
                      <span className="text-[9px] text-emerald-400/80 normal-case font-medium">Drag slider to compare</span>
                    </div>
                    <div 
                      ref={sliderRef}
                      className="comparison-slider-container relative select-none overflow-hidden rounded-lg mx-auto bg-black max-h-[34rem] w-fit flex items-center justify-center border border-border"
                      onPointerDown={(e) => {
                        setIsDraggingSlider(true);
                        if (!sliderRef.current) return;
                        const rect = sliderRef.current.getBoundingClientRect();
                        const x = e.clientX - rect.left;
                        setImageSliderPos(Math.max(0, Math.min(100, (x / rect.width) * 100)));
                      }}
                    >
                      {/* Background: Original Image */}
                      <img
                        src={activeImageItem.sourceUrl}
                        alt="Original Image"
                        className="mx-auto block max-h-[34rem] w-auto max-w-full object-contain pointer-events-none select-none"
                      />
                      
                      {/* Overlay: Cleaned Image */}
                      <div 
                        className="absolute inset-y-0 left-0 right-0 overflow-hidden pointer-events-none flex items-center justify-center"
                        style={{ clipPath: `inset(0 0 0 ${imageSliderPos}%)` }}
                      >
                        <img
                          src={activeImageItem.outputUrl}
                          alt="Cleaned Image"
                          className="mx-auto block max-h-[34rem] w-auto max-w-full object-contain pointer-events-none select-none"
                        />
                      </div>
                      
                      {/* Divider Line & Handle */}
                      <div 
                        className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize z-10 comparison-slider-handle flex items-center justify-center"
                        style={{ left: `${imageSliderPos}%`, transform: 'translateX(-50%)' }}
                      >
                        <div className="w-8 h-8 rounded-full bg-white text-black shadow-lg border border-neutral-300 flex items-center justify-center pointer-events-none select-none hover:scale-105 active:scale-95 transition-transform">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-700">
                            <path d="m9 18-6-6 6-6" />
                            <path d="m15 6 6 6-6 6" />
                          </svg>
                        </div>
                      </div>

                      {/* Labels */}
                      <div className="absolute top-2 left-2 bg-black/75 text-white/90 text-[9px] font-black uppercase tracking-wider px-2 py-1 rounded border border-white/10 pointer-events-none">
                        Original
                      </div>
                      <div className="absolute top-2 right-2 bg-emerald-500/90 text-white text-[9px] font-black uppercase tracking-wider px-2 py-1 rounded border border-emerald-400/20 pointer-events-none">
                        Cleaned
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className={hasImageOutput ? "grid gap-4 md:grid-cols-2" : "grid gap-4"}>
                    {/* Original Image Box */}
                    <div className="min-w-0">
                      <div className="mb-2 text-[10px] font-black uppercase tracking-[0.18em] text-white/65 flex justify-between items-center">
                        <span>Original Image</span>
                        <span className="text-[9px] text-muted-foreground normal-case font-medium">Click to expand</span>
                      </div>
                      <div className="relative mx-auto max-h-[34rem] w-fit rounded-lg overflow-hidden bg-black flex items-center justify-center border border-border/40">
                        <img
                          src={activeImageItem.sourceUrl}
                          alt="Original Uploaded Source"
                          onClick={() => {
                            setLightboxUrl(activeImageItem.sourceUrl);
                            setLightboxTitle("Original Image Preview");
                          }}
                          className="mx-auto block max-h-[34rem] w-auto max-w-full object-contain cursor-zoom-in hover:opacity-95 active:scale-[0.99] transition-all"
                        />
                        {activeImageItem.detectedPos && (
                          <div 
                            className="absolute border-2 border-dashed border-red-500 pointer-events-none animate-pulse z-10 flex flex-col justify-end p-1"
                            style={{
                              left: `${(activeImageItem.detectedPos.x / activeImageItem.width) * 100}%`,
                              top: `${(activeImageItem.detectedPos.y / activeImageItem.height) * 100}%`,
                              width: `${(activeImageItem.targetWatermarkSize / activeImageItem.width) * 100}%`,
                              height: `${(activeImageItem.targetWatermarkSize / activeImageItem.height) * 100}%`,
                            }}
                          >
                            <span className="bg-red-500/95 text-white font-sans font-bold text-[8px] px-1 py-0.5 rounded leading-none absolute -bottom-5 left-0 whitespace-nowrap shadow-md border border-red-400/20">
                              Logo Match
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Cleaned Image Box */}
                    {activeImageItem.outputUrl && (
                      <div className="min-w-0">
                        <div className="mb-2 text-[10px] font-black uppercase tracking-[0.18em] text-emerald-300 flex justify-between items-center">
                          <span>Cleaned Output Preview</span>
                          <span className="text-[9px] text-emerald-400/80 normal-case font-medium">Click to expand</span>
                        </div>
                        <div className="relative mx-auto max-h-[34rem] w-fit rounded-lg overflow-hidden bg-black flex items-center justify-center border border-emerald-500/20">
                          <img
                            src={activeImageItem.outputUrl}
                            alt="Watermark Cleaned Result"
                            onClick={() => {
                              setLightboxUrl(activeImageItem.outputUrl);
                              setLightboxTitle("Cleaned Output Preview");
                            }}
                            className="mx-auto block max-h-[34rem] w-auto max-w-full object-contain cursor-zoom-in hover:opacity-95 active:scale-[0.99] transition-all"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <button
                type="button"
                onClick={handleChooseImageClick}
                className="flex min-h-80 w-full flex-col items-center justify-center border border-dashed border-primary/20 rounded-lg px-5 text-center transition-all hover:bg-primary/[0.02] hover:border-primary/40 bg-transparent cursor-pointer"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary/50">
                  <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
                  <circle cx="9" cy="9" r="2" />
                  <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
                </svg>
                <span className="mt-4 text-base font-medium text-foreground">Upload JPEG, PNG, or WEBP images</span>
                <span className="mt-1 text-xs text-muted-foreground">Watermark detected in bottom-right corner automatically</span>
              </button>
            )
          )}
        </div>

        {/* Right Side: Sidebar Controls */}
        <div className="flex flex-col gap-5 p-5 sm:p-6 border-t lg:border-t-0 lg:border-l border-border bg-card">
          
          {/* VIDEO CONTROLS SIDEBAR */}
          {workspaceMode === "video" && (
            <>
              <div>
                <div className="text-[10px] font-black uppercase tracking-[0.18em] text-muted-foreground flex justify-between items-center">
                  <span>Video Queue</span>
                  {queue.length > 0 && (
                    <span className="text-[9px] bg-primary/10 text-primary font-bold px-2 py-0.5 rounded-full normal-case tracking-normal">
                      {queue.length} {queue.length === 1 ? "file" : "files"}
                    </span>
                  )}
                </div>

                {/* Render the Queue List here at the top of the sidebar */}
                {queue.length > 0 && (
                  <div className="mt-3 grid max-h-40 gap-1.5 overflow-y-auto pr-1 border-b border-border/50 pb-3">
                    {queue.map((item, index) => {
                      const isActive = item.id === activeItem?.id;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => setSelectedId(item.id)}
                          className={`flex items-center justify-between gap-2.5 rounded-md border p-2 text-left transition-colors cursor-pointer w-full ${
                            isActive
                              ? "border-primary bg-primary/5 text-foreground"
                              : "border-border hover:border-primary/20 bg-transparent text-muted-foreground hover:text-foreground"
                          }`}
                        >
                          <span className="min-w-0 flex-1">
                            <span className="block truncate text-[11px] font-bold">
                              {index + 1}. {item.name}
                            </span>
                            <span className="mt-0.5 block text-[10px] capitalize flex items-center justify-between">
                              <span className="opacity-70">{item.dimensions?.replace("x", " x ") || "Detecting..."}</span>
                              <span className={`font-bold ${
                                item.status === "done" ? "text-emerald-500" :
                                item.status === "processing" ? "text-primary animate-pulse" :
                                item.status === "error" ? "text-destructive" :
                                "text-muted-foreground"
                              }`}>
                                {item.status === "processing" ? `${Math.round(item.progress)}%` : item.status}
                              </span>
                            </span>
                          </span>
                          <span
                            role="button"
                            tabIndex={0}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRemoveVideo(item.id, e);
                            }}
                            className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                            aria-label={`Remove ${item.name}`}
                          >
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                              <polyline points="3 6 5 6 21 6" />
                              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
                            </svg>
                          </span>
                        </button>
                      );
                    })}
                  </div>
                )}

                <div className="mt-3 text-xs font-bold text-foreground truncate">
                  Selected: {activeItem ? activeItem.name : "None"}
                </div>
                {activeItem?.dimensions && (
                  <div className="mt-1 text-[11px] text-muted-foreground">
                    Resolution: {activeItem.dimensions.replace("x", " x ")}
                  </div>
                )}
              </div>

              {activeItem?.error && (
                <div className="flex gap-2 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-xs font-bold leading-5 text-destructive">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mt-0.5 shrink-0">
                    <circle cx="12" cy="12" r="10" />
                    <line x1="12" y1="8" x2="12" y2="12" />
                    <line x1="12" y1="16" x2="12.01" y2="16" />
                  </svg>
                  <span>{activeItem.error}</span>
                </div>
              )}

              {overallError && !activeItem?.error && (
                <div className="flex gap-2 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-xs font-bold leading-5 text-destructive">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mt-0.5 shrink-0">
                    <circle cx="12" cy="12" r="10" />
                    <line x1="12" y1="8" x2="12" y2="12" />
                    <line x1="12" y1="16" x2="12.01" y2="16" />
                  </svg>
                  <span>{overallError}</span>
                </div>
              )}

              {isReady && activeItem?.status === "ready" && (
                <div className="flex gap-2 rounded-md border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs font-bold leading-5 text-emerald-700 dark:text-emerald-300">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mt-0.5 shrink-0">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                  <span>Ready for local processing.</span>
                </div>
              )}

              {/* VIDEO SUBTRACTION ADJUSTMENTS */}
              {activeItem && activeItem.status !== "error" && (
                <div className="flex flex-col gap-4 border-t border-border pt-4 mt-2">
                  <label className="text-[10px] font-black uppercase tracking-[0.18em] text-muted-foreground">
                    Subtractive Fine-Tuning
                  </label>
                  
                  {/* Size adjustment slider */}
                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-[0.18em] text-muted-foreground">
                      <span>Mask Size Offset</span>
                      <span>{videoSettings.sizeAdjustment > 0 ? `+${videoSettings.sizeAdjustment}` : videoSettings.sizeAdjustment}px</span>
                    </div>
                    <input
                      type="range"
                      min="-15"
                      max="15"
                      value={videoSettings.sizeAdjustment}
                      disabled={isProcessing}
                      onChange={(e) => handleVideoSettingChange("sizeAdjustment", parseInt(e.target.value))}
                      className="w-full h-1 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
                    />
                  </div>

                  {/* Opacity slider */}
                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-[0.18em] text-muted-foreground">
                      <span>Subtraction Opacity</span>
                      <span>{Math.round(videoSettings.opacity * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      value={videoSettings.opacity * 100}
                      disabled={isProcessing}
                      onChange={(e) => handleVideoSettingChange("opacity", parseFloat((e.target.value / 100).toFixed(2)))}
                      className="w-full h-1 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
                    />
                  </div>

                  {/* Brightness/Color slider */}
                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-[0.18em] text-muted-foreground">
                      <span>Subtraction Brightness</span>
                      <span>{videoSettings.brightness}</span>
                    </div>
                    <input
                      type="range"
                      min="150"
                      max="255"
                      value={videoSettings.brightness}
                      disabled={isProcessing}
                      onChange={(e) => handleVideoSettingChange("brightness", parseInt(e.target.value))}
                      className="w-full h-1 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
                    />
                  </div>
                </div>
              )}

              {activeItem?.status === "processing" && (
                <div>
                  <div className="mb-2 flex items-center justify-between text-xs font-bold text-muted-foreground">
                    <span className="flex items-center gap-2">
                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="animate-spin">
                        <line x1="12" y1="2" x2="12" y2="6" />
                        <line x1="12" y1="18" x2="12" y2="22" />
                        <line x1="4.93" y1="4.93" x2="7.76" y2="7.76" />
                        <line x1="16.24" y1="16.24" x2="19.07" y2="19.07" />
                        <line x1="2" y1="12" x2="6" y2="12" />
                        <line x1="18" y1="12" x2="22" y2="12" />
                        <line x1="4.93" y1="19.07" x2="7.76" y2="16.24" />
                        <line x1="16.24" y1="7.76" x2="19.07" y2="4.93" />
                      </svg>
                      Processing...
                    </span>
                    <span>{Math.round(activeItem.progress)}%</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full bg-primary transition-all duration-300 origin-left"
                      style={{ width: `${activeItem.progress}%` }}
                    />
                  </div>
                </div>
              )}

              <input
                ref={fileInputRef}
                type="file"
                accept="video/*"
                multiple
                className="hidden"
                onChange={handleFileChange}
              />



              <div className="mt-auto grid gap-3">
                <button
                  onClick={handleChooseVideoClick}
                  disabled={isProcessing}
                  className="lovable-btn-outline inline-flex items-center justify-center gap-2 w-full h-11 text-sm font-medium"
                >
                  {queue.length > 0 ? "Add Videos" : "Choose Video"}
                </button>

                {queue.length > 1 ? (
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={handleCleanVideo}
                      disabled={!isReady || isProcessing}
                      className="lovable-btn-primary inline-flex items-center justify-center gap-2 w-full h-11 text-xs font-semibold px-2"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
                        <polyline points="9 11 12 14 22 4" />
                      </svg>
                      Clean Selected
                    </button>

                    <button
                      onClick={handleCleanAllVideos}
                      disabled={isProcessing || !queue.some(item => item.status === "ready" || item.status === "done" || item.status === "error")}
                      className="lovable-btn-primary inline-flex items-center justify-center gap-2 w-full h-11 text-xs font-semibold px-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 border-none shadow-sm"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M2 17L12 22L22 17" />
                        <path d="M2 12L12 17L22 12" />
                        <path d="M12 2L2 7L12 12L22 7L12 2Z" />
                      </svg>
                      Clean All ({queue.filter(item => item.status === "ready" || item.status === "done" || item.status === "error").length})
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={handleCleanVideo}
                    disabled={!isReady || isProcessing}
                    className="lovable-btn-primary inline-flex items-center justify-center gap-2 w-full h-11 text-sm font-medium"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
                      <polyline points="9 11 12 14 22 4" />
                    </svg>
                    Remove From Selected
                  </button>
                )}

                {queue.length > 1 ? (
                  queue.some(item => item.outputUrl) && (
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={handleDownload}
                        disabled={!activeItem?.outputUrl}
                        className="lovable-btn-success inline-flex items-center justify-center gap-2 w-full h-11 text-xs font-semibold px-2"
                      >
                        Download Selected
                      </button>
                      <button
                        onClick={handleDownloadAllVideos}
                        className="lovable-btn-success inline-flex items-center justify-center gap-2 w-full h-11 text-xs font-semibold px-2 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 border-none shadow-sm"
                      >
                        Download All ({queue.filter(item => item.outputUrl).length})
                      </button>
                    </div>
                  )
                ) : (
                  activeItem?.outputUrl && (
                    <button
                      onClick={handleDownload}
                      className="lovable-btn-success inline-flex items-center justify-center gap-2 w-full h-11 text-sm font-medium"
                    >
                      Download MP4
                    </button>
                  )
                )}

                {queue.length > 0 && (
                  <button
                    onClick={handleClearQueue}
                    disabled={isProcessing}
                    className="lovable-btn-outline inline-flex items-center justify-center gap-2 w-full h-11 text-sm font-medium border-red-500/20 text-red-500 hover:bg-red-500/5 hover:border-red-500/30"
                  >
                    Clear Queue
                  </button>
                )}
              </div>
            </>
          )}

          {/* IMAGE CONTROLS SIDEBAR */}
          {workspaceMode === "image" && (
            <>
              <div>
                <div className="text-[10px] font-black uppercase tracking-[0.18em] text-muted-foreground">
                  Image Queue
                </div>
                <div className="mt-3 text-sm font-bold text-foreground truncate">
                  {activeImageItem ? activeImageItem.name : "No image selected"}
                </div>
                {activeImageItem?.dimensions && (
                  <div className="mt-3 space-y-1.5 border-t border-border/60 pt-3">
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">Resolution:</span>
                      <span className="font-semibold text-foreground">{activeImageItem.dimensions.replace("x", " x ")}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">Analyzed Scale:</span>
                      <span className="font-semibold text-primary">{activeImageItem.scale}x</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">Watermark Area:</span>
                      <span className="font-semibold text-foreground">{activeImageItem.targetWatermarkSize} x {activeImageItem.targetWatermarkSize} px</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Cleaning Method selection */}
              <div className="flex flex-col gap-2 border-t border-border pt-4 mt-2">
                <label className="text-[10px] font-black uppercase tracking-[0.18em] text-muted-foreground">
                  Cleaning Method
                </label>
                <select
                  value={imageSettings.method}
                  onChange={(e) => handleSettingChange("method", e.target.value)}
                  className="w-full text-xs bg-muted border border-border text-foreground p-2.5 rounded-[6px] outline-none focus:ring-1 focus:ring-primary/50 cursor-pointer"
                >
                  <option value="subtraction">AI Subtraction (Exact)</option>
                  <option value="blur">Gaussian Blur</option>
                  <option value="solid">Solid Color Fill</option>
                  <option value="clone">Texture Clone Patch</option>
                </select>
              </div>

              {/* Conditional Sliders and Color Pickers */}
              {imageSettings.method === "blur" && (
                <div className="flex flex-col gap-2">
                  <div className="flex justify-between text-[10px] font-black uppercase tracking-[0.18em] text-muted-foreground">
                    <span>Blur Radius</span>
                    <span>{imageSettings.radius}px</span>
                  </div>
                  <input
                    type="range"
                    min="2"
                    max="30"
                    value={imageSettings.radius}
                    onChange={(e) => handleSettingChange("radius", parseInt(e.target.value))}
                    className="w-full h-1 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
                  />
                </div>
              )}

              {imageSettings.method === "solid" && (
                <div className="flex flex-col gap-2">
                  <div className="flex justify-between text-[10px] font-black uppercase tracking-[0.18em] text-muted-foreground">
                    <span>Fill Color</span>
                    <span>{imageSettings.solidColor || "Auto-detect"}</span>
                  </div>
                  <div className="flex gap-2">
                    <input
                      type="color"
                      value={imageSettings.solidColor || "#000000"}
                      onChange={(e) => handleSettingChange("solidColor", e.target.value)}
                      className="h-8 w-12 rounded border border-border bg-transparent p-0 cursor-pointer"
                    />
                    <button
                      onClick={() => handleSettingChange("solidColor", "")}
                      className="text-xs border border-border rounded-[6px] px-2.5 hover:bg-muted/40 transition-colors cursor-pointer"
                    >
                      Auto
                    </button>
                  </div>
                </div>
              )}

              {imageSettings.method === "clone" && (
                <div className="flex flex-col gap-3">
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-[0.18em] text-muted-foreground">
                      <span>Clone X Offset</span>
                      <span>{imageSettings.cloneOffset.x}px</span>
                    </div>
                    <input
                      type="range"
                      min="-300"
                      max="300"
                      value={imageSettings.cloneOffset.x}
                      onChange={(e) => handleCloneOffsetChange("x", e.target.value)}
                      className="w-full h-1 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-[0.18em] text-muted-foreground">
                      <span>Clone Y Offset</span>
                      <span>{imageSettings.cloneOffset.y}px</span>
                    </div>
                    <input
                      type="range"
                      min="-300"
                      max="300"
                      value={imageSettings.cloneOffset.y}
                      onChange={(e) => handleCloneOffsetChange("y", e.target.value)}
                      className="w-full h-1 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
                    />
                  </div>
                </div>
              )}

              {(imageSettings.method === "solid" || imageSettings.method === "clone") && (
                <div className="flex flex-col gap-2">
                  <div className="flex justify-between text-[10px] font-black uppercase tracking-[0.18em] text-muted-foreground">
                    <span>Feather Border</span>
                    <span>{imageSettings.feather}px</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="30"
                    value={imageSettings.feather}
                    onChange={(e) => handleSettingChange("feather", parseInt(e.target.value))}
                    className="w-full h-1 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
                  />
                </div>
              )}

              {/* Error alerts */}
              {activeImageItem?.error && (
                <div className="flex gap-2 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-xs font-bold leading-5 text-destructive">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mt-0.5 shrink-0">
                    <circle cx="12" cy="12" r="10" />
                    <line x1="12" y1="8" x2="12" y2="12" />
                    <line x1="12" y1="16" x2="12.01" y2="16" />
                  </svg>
                  <span>{activeImageItem.error}</span>
                </div>
              )}

              {overallError && !activeImageItem?.error && (
                <div className="flex gap-2 rounded-md border border-destructive/30 bg-destructive/10 p-3 text-xs font-bold leading-5 text-destructive">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mt-0.5 shrink-0">
                    <circle cx="12" cy="12" r="10" />
                    <line x1="12" y1="8" x2="12" y2="12" />
                    <line x1="12" y1="16" x2="12.01" y2="16" />
                  </svg>
                  <span>{overallError}</span>
                </div>
              )}

              {isImageReady && activeImageItem?.status === "ready" && (
                <div className="flex gap-2 rounded-md border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs font-bold leading-5 text-emerald-700 dark:text-emerald-300">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mt-0.5 shrink-0">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                  <span>Ready for canvas cleaning.</span>
                </div>
              )}

              {activeImageItem?.status === "processing" && (
                <div>
                  <div className="mb-2 flex items-center justify-between text-xs font-bold text-muted-foreground">
                    <span className="flex items-center gap-2">
                      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="animate-spin">
                        <line x1="12" y1="2" x2="12" y2="6" />
                        <line x1="12" y1="18" x2="12" y2="22" />
                        <line x1="4.93" y1="4.93" x2="7.76" y2="7.76" />
                        <line x1="16.24" y1="16.24" x2="19.07" y2="19.07" />
                        <line x1="2" y1="12" x2="6" y2="12" />
                        <line x1="18" y1="12" x2="22" y2="12" />
                        <line x1="4.93" y1="19.07" x2="7.76" y2="16.24" />
                        <line x1="16.24" y1="7.76" x2="19.07" y2="4.93" />
                      </svg>
                      Processing...
                    </span>
                    <span>{Math.round(activeImageItem.progress)}%</span>
                  </div>
                  <div className="h-2 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full bg-primary transition-all duration-300 origin-left"
                      style={{ width: `${activeImageItem.progress}%` }}
                    />
                  </div>
                </div>
              )}

              <input
                ref={imageFileInputRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={handleImageFileChange}
              />

              {imageQueue.length > 0 && (
                <div className="grid max-h-36 gap-2 overflow-y-auto pr-1">
                  {imageQueue.map((item, index) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setSelectedImageId(item.id)}
                      className={`flex items-center justify-between gap-3 rounded-md border p-3 text-left transition-colors cursor-pointer w-full ${item.id === activeImageItem?.id
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/30 bg-transparent"
                        }`}
                    >
                      <span className="min-w-0">
                        <span className="block truncate text-xs font-black text-foreground">
                          {index + 1}. {item.name}
                        </span>
                        <span className="mt-1 block text-[11px] font-bold capitalize text-muted-foreground">
                          {item.status}
                          {item.status === "processing" ? ` ${Math.round(item.progress)}%` : ""}
                        </span>
                      </span>
                      <span
                        role="button"
                        tabIndex={0}
                        onClick={(e) => handleRemoveImage(item.id, e)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            e.preventDefault();
                            handleRemoveImage(item.id, e);
                          }
                        }}
                        className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
                        aria-label={`Remove ${item.name}`}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <polyline points="3 6 5 6 21 6" />
                          <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
                        </svg>
                      </span>
                    </button>
                  ))}
                </div>
              )}

              <div className="mt-auto grid gap-3">
                <button
                  onClick={handleChooseImageClick}
                  disabled={isImageProcessing}
                  className="lovable-btn-outline inline-flex items-center justify-center gap-2 w-full h-11 text-sm font-medium"
                >
                  {imageQueue.length > 0 ? "Add Images" : "Choose Image"}
                </button>

                <button
                  onClick={handleCleanImage}
                  disabled={!isImageReady || isImageProcessing}
                  className="lovable-btn-primary inline-flex items-center justify-center gap-2 w-full h-11 text-sm font-medium"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
                    <polyline points="9 11 12 14 22 4" />
                  </svg>
                  Remove From Selected
                </button>

                {activeImageItem?.outputUrl && (
                  <button
                    onClick={handleDownloadImage}
                    className="lovable-btn-success inline-flex items-center justify-center gap-2 w-full h-11 text-sm font-medium"
                  >
                    Download Image
                  </button>
                )}

                {imageQueue.length > 0 && (
                  <button
                    onClick={handleClearImageQueue}
                    disabled={isImageProcessing}
                    className="lovable-btn-outline inline-flex items-center justify-center gap-2 w-full h-11 text-sm font-medium border-red-500/20 text-red-500 hover:bg-red-500/5 hover:border-red-500/30"
                  >
                    Clear Queue
                  </button>
                )}
              </div>
            </>
          )}

          <p className="text-xs leading-5 text-muted-foreground border-t border-border pt-4 mt-2">
            Processing happens locally on your device. Original files are never uploaded to any server.
          </p>
        </div>
      </div>

      {/* Lightbox Modal Popup */}
      {lightboxUrl && (
        <div 
          onClick={() => setLightboxUrl(null)}
          className="fixed inset-0 z-[9999] flex flex-col items-center justify-between bg-black/90 backdrop-blur-md p-4 sm:p-6 select-none animate-fade-in"
        >
          {/* Header Bar */}
          <div className="w-full max-w-7xl flex items-center justify-between text-white border-b border-white/10 pb-3">
            <div className="flex flex-col">
              <span className="text-sm font-semibold tracking-wide">{lightboxTitle}</span>
              {activeImageItem && (
                <span className="text-[11px] text-white/60">
                  {activeImageItem.name} ({activeImageItem.dimensions})
                </span>
              )}
            </div>
            <button 
              onClick={() => setLightboxUrl(null)}
              className="inline-flex items-center justify-center p-2 rounded-full bg-white/5 hover:bg-white/10 text-white/80 hover:text-white transition-colors cursor-pointer"
              aria-label="Close Preview"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          </div>

          {/* Main Image View */}
          <div 
            onClick={(e) => e.stopPropagation()} 
            className="relative flex items-center justify-center flex-1 my-4 max-w-[80%] max-h-[55vh] p-2 bg-neutral-900/40 rounded-xl border border-white/10 shadow-inner"
          >
            <img 
              src={lightboxUrl} 
              alt="Expanded Preview" 
              className="max-h-[50vh] max-w-[70vw] object-contain rounded-lg shadow-xl border border-white/5 select-text animate-scale-up"
            />
          </div>

          {/* Footer Bar */}
          <div className="w-full max-w-7xl flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-white/10 pt-3">
            <span className="text-xs text-white/50">
              Press Escape or click outside to dismiss
            </span>
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setLightboxUrl(null)}
                className="px-4 py-2 text-xs font-semibold text-white/80 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 rounded-md transition-colors cursor-pointer"
              >
                Close View
              </button>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  const cleanName = `${activeImageItem?.name.replace(/\.[^.]+$/, "") || "cleaned"}-expanded.png`;
                  downloadFile(lightboxUrl, cleanName);
                }}
                className="inline-flex items-center gap-2 px-5 py-2 text-xs font-bold text-black bg-white hover:bg-white/90 rounded-md transition-colors shadow-md cursor-pointer"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                  <polyline points="7 10 12 15 17 10" />
                  <line x1="12" y1="15" x2="12" y2="3" />
                </svg>
                Download Image
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
