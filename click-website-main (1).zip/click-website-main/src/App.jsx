import { useState } from "react";
import WatermarkRemover from "./components/WatermarkRemover";
import "./index.css"; // Ensure index.css is loaded

export default function App() {
  const [playDemo, setPlayDemo] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="relative flex min-h-screen flex-col bg-background text-foreground">
      {/* Top Navbar */}
      <header className="fixed inset-x-0 top-0 z-50 py-4 glassmorphism-header transition-colors duration-200">
        <nav className="max-w-6xl mx-auto px-6 flex items-center justify-between">
          <a className="group flex items-center gap-2.5" href="/">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg border border-border bg-card text-foreground shadow-sm transition-all duration-200 group-hover:scale-105 group-hover:border-primary/30">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary">
                <circle cx="12" cy="12" r="10" />
                <path d="M12 2a7 7 0 1 0 10 10" />
                <path d="m12 8-1 2-2 1 2 1 1 2 1-2 2-1-2-1z" />
              </svg>
            </div>
            <span className="font-sans text-sm tracking-tight text-foreground flex items-center gap-1.5">
              <span className="font-bold">Gemini</span>
              <span className="text-muted-foreground font-normal">Watermark Remover</span>
            </span>
          </a>

          {/* Desktop Nav Links & CTA */}
          <div className="hidden items-center gap-6 md:flex">
            <ul className="flex items-center gap-6">
              <li><a className="text-sm font-medium transition-colors text-muted-foreground hover:text-foreground" href="/">Home</a></li>
              <li><a className="text-sm font-medium transition-colors text-muted-foreground hover:text-foreground" href="https://t.me/sparklydeep" target="_blank" rel="noopener noreferrer">Telegram</a></li>
              <li><a className="text-sm font-medium transition-colors text-muted-foreground hover:text-foreground" href="#how-to-use">How To Use</a></li>
            </ul>
            <a href="#studio" className="lovable-btn-primary text-xs font-semibold px-4 py-2 rounded-[6px] transition-all">
              Launch Studio
            </a>
          </div>

          {/* Mobile hamburger menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="inline-flex h-9 w-9 items-center justify-center rounded-[6px] border border-border bg-card text-foreground md:hidden transition-colors hover:bg-muted/30"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? (
              // Close Icon
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            ) : (
              // Menu Icon
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="4" y1="12" x2="20" y2="12" />
                <line x1="4" y1="6" x2="20" y2="6" />
                <line x1="4" y1="18" x2="20" y2="18" />
              </svg>
            )}
          </button>
        </nav>

        {/* Mobile dropdown menu overlay */}
        {mobileMenuOpen && (
          <div className="absolute top-full inset-x-0 glassmorphism-dropdown py-5 px-6 md:hidden shadow-lg transition-all duration-200">
            <ul className="flex flex-col gap-4">
              <li>
                <a
                  onClick={() => setMobileMenuOpen(false)}
                  className="block text-sm font-medium text-muted-foreground hover:text-foreground py-1.5 transition-colors"
                  href="/"
                >
                  Home
                </a>
              </li>
              <li>
                <a
                  onClick={() => setMobileMenuOpen(false)}
                  className="block text-sm font-medium text-muted-foreground hover:text-foreground py-1.5 transition-colors"
                  href="https://t.me/sparklydeep"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Telegram
                </a>
              </li>
              <li>
                <a
                  onClick={() => setMobileMenuOpen(false)}
                  className="block text-sm font-medium text-muted-foreground hover:text-foreground py-1.5 transition-colors"
                  href="#how-to-use"
                >
                  How To Use
                </a>
              </li>
              <li className="pt-2 border-t border-border/30">
                <a
                  onClick={() => setMobileMenuOpen(false)}
                  href="#studio"
                  className="lovable-btn-primary block text-center text-xs font-semibold py-2.5 rounded-[6px]"
                >
                  Launch Studio
                </a>
              </li>
            </ul>
          </div>
        )}
      </header>

      {/* Main content wrapper */}
      <main className="flex-1 pt-24 pb-16 max-w-6xl mx-auto px-6 w-full relative">
        {/* Glow backdrop decorative layout */}
        <div className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80" aria-hidden="true">
          <div className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-primary to-[#ec4899] opacity-20 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"></div>
        </div>

        {/* Breadcrumb & Intro header */}
        <section className="border-b border-border/20 pb-10 pt-5">
          <h1 className="mt-6 max-w-4xl mx-auto text-center text-4xl font-black text-foreground sm:text-5xl lg:text-6xl tracking-tight leading-tight">
            Gemini Watermark remover
          </h1>
        </section>

        {/* WORKSPACE SECTION */}
        <section id="studio" className="mt-10" aria-label="Gemini video watermark remover tool">
          <WatermarkRemover />
        </section>

        {/* Steps section */}
        <section id="how-to-use" className="lovable-theme mt-14 border border-border bg-card text-foreground rounded-2xl p-8 md:p-10 shadow-sm">
          <div className="grid gap-8 lg:grid-cols-[0.85fr_1.15fr]">
            <div className="flex flex-col justify-between h-full">
              <div>
                <span className="text-xs font-bold uppercase tracking-[0.2em] text-muted-foreground">How It Works</span>
                <h2 className="mt-3 text-3xl font-black text-foreground tracking-tight leading-tight">Three short steps</h2>
              </div>
              <div className="mt-6 border border-border rounded-xl overflow-hidden bg-muted/20 p-1">
                <img 
                  src="/watermark_cleanup_demo.png" 
                  alt="Watermark Removal Demonstration Graphic" 
                  className="w-full h-auto rounded-lg object-contain"
                />
              </div>
            </div>
            <ol className="grid gap-6">
              <li className="flex gap-4 border-b border-border pb-5 items-start">
                <span className="text-3xl font-black text-foreground tracking-tight leading-none">01</span>
                <div>
                  <h3 className="text-sm font-bold text-foreground">Select Supported Video</h3>
                  <p className="text-sm text-muted-foreground mt-1">Choose an exact 720p (1280 x 720 / 720 x 1280) or 1080p (1920 x 1080 / 1080 x 1920) Gemini video from your device.</p>
                  <ul className="mt-2 space-y-1 text-xs text-muted-foreground list-disc pl-4">
                    <li>Supports exact 720p (<strong>1280 x 720</strong> & <strong>720 x 1280</strong>) and 1080p (<strong>1920 x 1080</strong> & <strong>1080 x 1920</strong>) landscape and portrait dimensions.</li>
                    <li><strong>Why only these resolutions?</strong> The client-side AI subtraction logic uses a pre-calibrated watermark mask scaled dynamically to match 720p and 1080p resolutions. Processing other sizes would lead to misalignment, causing visual artifacts or incomplete logo removal.</li>
                    <li>Files are processed locally in-browser—no servers or video uploads.</li>
                  </ul>
                </div>
              </li>
              <li className="flex gap-4 border-b border-border pb-5 items-start">
                <span className="text-3xl font-black text-foreground tracking-tight leading-none">02</span>
                <div>
                  <h3 className="text-sm font-bold text-foreground">Run Cleanup Process</h3>
                  <p className="text-sm text-muted-foreground mt-1">Run the Gemini video logo remover and keep this tab open while local processing finishes.</p>
                  <ul className="mt-2 space-y-1 text-xs text-muted-foreground list-disc pl-4">
                    <li>Click on the cleanup action to trigger the frame-by-frame corner repair.</li>
                    <li>Do not close or minimize this tab to avoid browser performance throttling.</li>
                  </ul>
                </div>
              </li>
              <li className="flex gap-4 items-start">
                <span className="text-3xl font-black text-foreground tracking-tight leading-none">03</span>
                <div>
                  <h3 className="text-sm font-bold text-foreground">Download Cleaned Result</h3>
                  <p className="text-sm text-muted-foreground mt-1">Download the cleaned MP4 file and review the visible corner area before using the result.</p>
                  <ul className="mt-2 space-y-1 text-xs text-muted-foreground list-disc pl-4">
                    <li>Grab your instantly compiled high-quality MP4 download.</li>
                    <li>Verify the corner logo cleanup region before sharing or using the video.</li>
                  </ul>
                </div>
              </li>
            </ol>
          </div>
        </section>
      </main>

      <footer className="mt-32 pb-16 w-full">
        <div className="max-w-6xl mx-auto px-6">
          <div className="lovable-theme bg-card text-foreground border border-border rounded-xl px-6 py-5 flex flex-col md:flex-row items-center justify-center gap-4 shadow-sm">
            <div className="flex flex-col md:flex-row items-center gap-2 md:gap-4 text-center md:text-left">
              <a className="flex items-center gap-2 font-medium" href="/">
                <div className="flex h-6 w-6 items-center justify-center rounded bg-primary text-primary-foreground">
                  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10" />
                    <path d="M12 2a7 7 0 1 0 10 10" />
                  </svg>
                </div>
                <span className="text-sm">
                  <span className="font-bold">Gemini</span> <span className="text-muted-foreground">Watermark Remover</span>
                </span>
              </a>
              <span className="hidden md:inline text-border">|</span>
              <span className="text-xs text-muted-foreground">© 2026. All rights reserved.</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
